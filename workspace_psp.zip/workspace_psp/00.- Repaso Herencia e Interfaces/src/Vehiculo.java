// Definimos una interfaz llamada Vehiculo
// Una interfaz es como un contrato que dice qué métodos deben tener las clases que la implementen
public interface Vehiculo {
    // Método para acelerar el vehículo
    void acelerar();
    
    // Método para frenar el vehículo
    void frenar();
    
    // Método para obtener la velocidad actual del vehículo
    int obtenerVelocidad();
}