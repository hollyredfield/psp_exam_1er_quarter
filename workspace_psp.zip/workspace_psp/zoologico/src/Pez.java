public class Pez extends AnimalBase{
    public Pez (String nombre) {
        super(nombre);
    }
    public void nadar() {
        System.out.println(getNombre() + "Está nadando. ");
    }
}
