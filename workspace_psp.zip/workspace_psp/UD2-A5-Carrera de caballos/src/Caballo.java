// Importamos las clases necesarias para escribir en archivos
import java.io.FileWriter;
import java.io.IOException;

// Creamos la clase Caballo que implementa Runnable para poder ejecutarse en un hilo
public class Caballo implements Runnable {
    // Variables para guardar los datos del caballo
    private String nombre;        // Nombre del caballo
    private String carrera;       // Nombre de la carrera
    private FileWriter writer;    // Para escribir en el archivo
    private static int posicionLlegada = 0;  // Para saber en qué posición llega cada caballo

    // Constructor - se ejecuta al crear un nuevo caballo
    public Caballo(String nombre, String carrera) {
        this.nombre = nombre;    // Guardamos el nombre
        this.carrera = carrera;  // Guardamos la carrera
        try {
            // Creamos un archivo con el nombre de la carrera (ej: carrera1.txt)
            this.writer = new FileWriter(carrera + ".txt", true);
            // Escribimos que el caballo empieza la carrera
            writer.write("Inicio de carrera para " + nombre + "\n");
            writer.flush();  // Nos aseguramos que se escribe en el archivo
        } catch (IOException e) {
            // Si hay error al crear el archivo, mostramos mensaje
            System.out.println("Error al crear archivo para " + nombre);
        }
    }

    // Método que se ejecuta cuando el caballo corre
    @Override
    public void run() {
        try {
            // El caballo avanza de 25 en 25 metros hasta 100
            for(int i = 0; i <= 100; i += 25) {
                // Escribimos cuánto ha avanzado
                writer.write(nombre + " ha avanzado hasta " + i + " metros\n");
                writer.flush();  // Guardamos en el archivo
                Thread.sleep(500);  // Esperamos medio segundo
            }
            
            // Cuando termina, guardamos su posición de llegada
            synchronized(Caballo.class) {  // Solo un caballo puede escribir a la vez
                posicionLlegada++;  // Aumentamos la posición
                // Escribimos en qué posición llegó
                writer.write(nombre + " ha llegado en posición " + posicionLlegada + "\n");
                writer.flush();  // Guardamos en el archivo
            }
            
            writer.close();  // Cerramos el archivo
        } catch (Exception e) {
            // Si hay algún error durante la carrera, mostramos mensaje
            System.out.println("Error en la carrera de " + nombre);
        }
    }
}