// Main.java
public class Main {
    public static void main(String[] args) {
        try {
            // Crea un ProcessBuilder para ejecutar la calculadora (calc.exe)
            ProcessBuilder pb = new ProcessBuilder("calc.exe");
            // Inicia el proceso para abrir la calculadora
            pb.start();
            // Imprime un mensaje indicando que la calculadora se ha iniciado
            System.out.println("Calculadora iniciada");
        } catch (Exception e) {
            // Si hay un error al abrir la calculadora, lo muestra
            System.out.println("Error al abrir calculadora");
        }
    }
}