public class Main {
    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria();

        Thread cliente1 = new Thread(() -> cuenta.retirarDinero(50, "Cliente 1"));
        Thread cliente2 = new Thread(() -> cuenta.retirarDinero(50, "Cliente 2"));
        Thread cliente3 = new Thread(() -> cuenta.retirarDinero(50, "Cliente 3"));

        cliente1.start();
        cliente2.start();
        cliente3.start();
    }
}
