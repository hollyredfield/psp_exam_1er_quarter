
import java.io.*;

public class A6 {
    public static void main(String[] args) throws IOException {
        for (int i = 5; i <= 7; i++) {
            ProcessBuilder pb = new ProcessBuilder("java", "NumberTriangle", String.valueOf(i));
            pb.redirectOutput(new File("triangle" + i + ".txt"));
            pb.start();
        }
    }
}
