
import java.io.IOException;

public class CalculadoraProcess {
    public static void main(String[] args) {
        try {
            //crea un objeto ProcessBuilder para lanzar el programa calculadora
            ProcessBuilder processBuilder = new ProcessBuilder("calc.exe");
            //Inicia el proceso
            processBuilder.start();
            System.out.println("Se ha lanzado la calculadora con éxito");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
