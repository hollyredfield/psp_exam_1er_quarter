// Animal.java
public interface Animal { // Declara una interfaz llamada Animal
    void comer(); // Método abstracto para comer
    void dormir(); // Método abstracto para dormir
}
