public class MiHilo extends Thread {
    @Override
    public void run() {
        System.out.println("El hilo está en ejecución.");
    }
}
