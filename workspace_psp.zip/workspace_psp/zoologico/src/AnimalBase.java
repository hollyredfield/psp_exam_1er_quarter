abstract class AnimalBase implements Animal {
    protected String nombre;

    public AnimalBase(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre(){
        return nombre;
    }
    @Override
    public void comer(){
        System.out.println(nombre + " está comiendo");
    }
    @Override
    public void dormir(){
        System.out.println(nombre + " está durmiendo. ");
    }

}
