// Main.java
import java.io.BufferedReader; // Importa la clase BufferedReader para leer texto de una entrada
import java.io.InputStreamReader; // Importa la clase InputStreamReader para convertir bytes en caracteres

public class Main {
    public static void main(String[] args) {
        try {
            // Crea un ProcessBuilder para ejecutar el comando "tasklist"
            ProcessBuilder pb = new ProcessBuilder("tasklist");
            // Inicia el proceso
            Process proceso = pb.start();
            
            // Crea un BufferedReader para leer la salida del proceso
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(proceso.getInputStream())
            );
            
            String linea;
            // Lee cada línea de la salida del proceso y la imprime
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }
            
        } catch (Exception e) {
            // Imprime un mensaje de error si ocurre una excepción
            System.out.println("Error: " + e.getMessage());
        }
    }
}