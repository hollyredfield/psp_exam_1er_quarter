// Main.java
public class Main {
    public static void main(String[] args) {
        // Imprime un mensaje indicando que la carrera comienza
        System.out.println("¡Comienza la carrera!");
        
        // Crea un hilo para el corredor "Juan"
        Thread corredor1 = new Thread(new Corredor("Juan"));
        // Crea un hilo para el corredor "Pedro"
        Thread corredor2 = new Thread(new Corredor("Pedro"));
        // Crea un hilo para el corredor "Luis"
        Thread corredor3 = new Thread(new Corredor("Luis"));

        // Inicia el hilo del corredor "Juan"
        corredor1.start();
        // Inicia el hilo del corredor "Pedro"
        corredor2.start();
        // Inicia el hilo del corredor "Luis"
        corredor3.start();
    }
}