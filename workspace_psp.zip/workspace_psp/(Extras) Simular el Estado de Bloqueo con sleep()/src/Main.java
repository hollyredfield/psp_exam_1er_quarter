public class Main {
    public static void main(String[] args) {
        HiloConSleep hilo = new HiloConSleep();
        hilo.start();
    }
}
