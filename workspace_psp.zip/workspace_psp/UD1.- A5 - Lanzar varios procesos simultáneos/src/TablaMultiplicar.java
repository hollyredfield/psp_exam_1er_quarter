// TablaMultiplicar.java
import java.util.Date;

public class TablaMultiplicar {
    public static void main(String[] args) {
        if (args.length > 0) {
            int numero = Integer.parseInt(args[0]);
            System.out.println("Hora: " + new Date());
            System.out.println("Tabla del " + numero + ":");
            for (int i = 1; i <= 10; i++) {
                System.out.println(numero + " x " + i + " = " + (numero * i));
            }
        }
    }
}