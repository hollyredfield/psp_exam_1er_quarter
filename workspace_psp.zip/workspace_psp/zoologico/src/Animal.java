public interface Animal {
    void comer();
    void dormir();
}

