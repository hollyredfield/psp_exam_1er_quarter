public class Zoologico {
    public static void main(String[] args) {
        Pajaro pajaro = new Pajaro("Loro");
        Pez pez = new Pez ("Sardina");
        Mamifero mamifero = new Mamifero("Jirafa");

        mamifero.comer();
        mamifero.dormir();


        pez.comer();
        pez.dormir();
        pez.nadar();

        pajaro.volar();
        pajaro.comer();
        pajaro.dormir();
    }
}
