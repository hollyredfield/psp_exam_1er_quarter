// Corredor.java
public class Corredor implements Runnable { // Declara la clase Corredor que implementa la interfaz Runnable
    private String nombre; // Declara una variable para almacenar el nombre del corredor

    public Corredor(String nombre) { // Constructor de la clase Corredor
        this.nombre = nombre; // Asigna el nombre del corredor
    }

    @Override
    public void run() { // Método que se ejecuta cuando se inicia el hilo
        for(int i = 1; i <= 3; i++) { // Bucle que se ejecuta 3 veces
            // Imprime el número de vueltas que ha corrido el corredor
            System.out.println(nombre + " ha corrido " + i + " vueltas");
            try {
                // Espera 1000 milisegundos (1 segundo)
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                // Si hay un error durante la espera, lo muestra
                System.out.println("Error");
            }
        }
        // Imprime un mensaje indicando que el corredor ha terminado
        System.out.println(nombre + " ha terminado!");
    }
}