/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author holly
 */
// 4. Main.java - Ejecuta todo el programa
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Lista compartida entre productor y consumidor
        ArrayList<Double> radios = new ArrayList<>();
        
        // Crea y arranca los hilos
        Thread productor = new Thread(new Productor(radios));
        Thread consumidor = new Thread(new Consumidor(radios));
        
        productor.start();
        consumidor.start();
    }
}