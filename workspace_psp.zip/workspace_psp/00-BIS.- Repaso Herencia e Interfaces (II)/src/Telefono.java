// La clase Telefono implementa la interfaz Dispositivo
public class Telefono implements Dispositivo {
    // Atributo privado para almacenar el estado del teléfono (encendido o apagado)
    private boolean estaEncendido = false;

    // Implementación del método encender() de la interfaz Dispositivo
    @Override
    public void encender() {
        // Cambiamos el estado del teléfono a encendido
        estaEncendido = true;
        // Imprimimos un mensaje indicando que el teléfono está encendido
        System.out.println("Teléfono encendido");
    }

    // Implementación del método apagar() de la interfaz Dispositivo
    @Override
    public void apagar() {
        // Cambiamos el estado del teléfono a apagado
        estaEncendido = false;
        // Imprimimos un mensaje indicando que el teléfono está apagado
        System.out.println("Teléfono apagado");
    }

    // Implementación del método mostrarEstado() de la interfaz Dispositivo
    @Override
    public void mostrarEstado() {
        // Imprimimos el estado actual del teléfono (encendido o apagado)
        System.out.println("El teléfono está " + (estaEncendido ? "encendido" : "apagado"));
    }

    // Método específico de la clase Telefono para realizar una llamada
    public void realizarLlamada() {
        // Verificamos si el teléfono está encendido
        if (estaEncendido) {
            // Si está encendido, imprimimos un mensaje indicando que se está realizando una llamada
            System.out.println("Realizando llamada...");
        } else {
            // Si está apagado, imprimimos un mensaje indicando que el teléfono está apagado
            System.out.println("El teléfono está apagado");
        }
    }
}