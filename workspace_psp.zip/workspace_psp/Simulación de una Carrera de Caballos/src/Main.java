import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

class Caballo implements Runnable {
    private String nombre;
    private int distanciaRecorrida;
    private static final int META = 100;
    private Carrera carrera;

    public Caballo(String nombre, Carrera carrera) {
        this.nombre = nombre;
        this.carrera = carrera;
        this.distanciaRecorrida = 0;
    }

    @Override
    public void run() {
        Random random = new Random();
        while (distanciaRecorrida < META) {
            distanciaRecorrida += random.nextInt(10);
            System.out.println(nombre + " ha recorrido " + distanciaRecorrida + " metros.");
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        carrera.registrarLlegada(this);
    }

    public String getNombre() {
        return nombre;
    }
}

class Carrera {
    private List<Caballo> caballos;
    private List<String> resultados;

    public Carrera(List<Caballo> caballos) {
        this.caballos = caballos;
        this.resultados = Collections.synchronizedList(new ArrayList<>());
    }

    public void iniciarCarrera() {
        List<Thread> hilos = new ArrayList<>();
        for (Caballo caballo : caballos) {
            Thread hilo = new Thread(caballo);
            hilos.add(hilo);
            hilo.start();
        }
        for (Thread hilo : hilos) {
            try {
                hilo.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void registrarLlegada(Caballo caballo) {
        resultados.add(caballo.getNombre());
    }

    public void guardarResultados(String nombreArchivo) {
        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            for (int i = 0; i < resultados.size(); i++) {
                writer.write((i + 1) + ". " + resultados.get(i) + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        List<Caballo> caballosCarrera1 = new ArrayList<>();
        List<Caballo> caballosCarrera2 = new ArrayList<>();

        Carrera carrera1 = new Carrera(caballosCarrera1);
        Carrera carrera2 = new Carrera(caballosCarrera2);

        for (int i = 1; i <= 5; i++) {
            caballosCarrera1.add(new Caballo("Caballo " + i + " Carrera 1", carrera1));
            caballosCarrera2.add(new Caballo("Caballo " + i + " Carrera 2", carrera2));
        }

        Thread hiloCarrera1 = new Thread(() -> {
            carrera1.iniciarCarrera();
            carrera1.guardarResultados("resultados_carrera1.txt");
        });

        Thread hiloCarrera2 = new Thread(() -> {
            carrera2.iniciarCarrera();
            carrera2.guardarResultados("resultados_carrera2.txt");
        });

        hiloCarrera1.start();
        hiloCarrera2.start();

        try {
            hiloCarrera1.join();
            hiloCarrera2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}