public class A2 {
    public static void main(String[] args) {
        Corredor c1 = new Corredor("Corredor 1");
        Corredor c2 = new Corredor("Corredor 2");
        Corredor c3 = new Corredor("Corredor 3");

        c1.start();
        c2.start();
        c3.start();
    }
}