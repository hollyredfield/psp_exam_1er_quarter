// Main.java
import java.io.File;

public class Main {
    public static void main(String[] args) {
        try {
            // Obtener el classpath actual
            String classpath = System.getProperty("java.class.path");

            // Crear ProcessBuilders con el classpath explícito
            ProcessBuilder pb1 = new ProcessBuilder("java", "-cp", classpath, "Triangulo", "3");
            ProcessBuilder pb2 = new ProcessBuilder("java", "-cp", classpath, "Triangulo", "4");
            ProcessBuilder pb3 = new ProcessBuilder("java", "-cp", classpath, "Triangulo", "5");

            // Redirigir salida a archivos
            pb1.redirectOutput(new File("triangulo1.txt"));
            pb2.redirectOutput(new File("triangulo2.txt"));
            pb3.redirectOutput(new File("triangulo3.txt"));

            // Iniciar y esperar procesos
            Process p1 = pb1.start();
            Process p2 = pb2.start();
            Process p3 = pb3.start();

            // Esperar a que terminen
            p1.waitFor();
            p2.waitFor();
            p3.waitFor();

            System.out.println("Procesos completados - revisa los archivos triangulo1.txt, triangulo2.txt y triangulo3.txt");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
