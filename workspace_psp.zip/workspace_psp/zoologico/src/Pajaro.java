public class Pajaro extends AnimalBase {
    public Pajaro(String nombre) {
    super(nombre);
    }
    public void volar(){
    System.out.println(getNombre() + "está volando");
    }
}
