// Triangulo.java
public class Triangulo {
    public static void main(String[] args) {
        // Verifica si se ha pasado al menos un argumento
        if (args.length > 0) {
            // Convierte el primer argumento a un número entero (base del triángulo)
            int base = Integer.parseInt(args[0]);
            // Bucle externo que va desde la base hasta 1
            for (int i = base; i >= 1; i--) {
                // Bucle interno que imprime números desde 1 hasta el valor de i
                for (int j = 1; j <= i; j++) {
                    // Imprime el número j sin un salto de línea
                    System.out.print(j);
                }
                // Imprime un salto de línea después de cada fila de números
                System.out.println();
            }
        }
    }
}