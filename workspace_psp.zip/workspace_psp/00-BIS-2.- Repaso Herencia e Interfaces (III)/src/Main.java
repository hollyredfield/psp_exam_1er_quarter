// Main.java
public class Main {
    public static void main(String[] args) {
        // Crea un objeto de la clase Ave
        Ave pajaro = new Ave();
        // Llama al método comer del objeto pajaro
        pajaro.comer();
        // Llama al método dormir del objeto pajaro
        pajaro.dormir();
        // Llama al método volar del objeto pajaro
        pajaro.volar();
    }
}