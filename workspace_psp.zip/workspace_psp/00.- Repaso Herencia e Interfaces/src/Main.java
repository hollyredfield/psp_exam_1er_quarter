// Definimos la clase principal Main
public class Main {
    // Método principal que se ejecuta al iniciar el programa
    public static void main(String[] args) {
        // Creamos una instancia de la clase Coche
        Coche miCoche = new Coche();
        
        // Llamamos al método acelerar() para incrementar la velocidad del coche
        miCoche.acelerar();
        // Llamamos nuevamente al método acelerar() para incrementar más la velocidad del coche
        miCoche.acelerar();
        // Llamamos al método usarAireAcondicionado() para cambiar el estado del aire acondicionado
        miCoche.usarAireAcondicionado();
        // Llamamos al método frenar() para reducir la velocidad del coche
        miCoche.frenar();
        // Imprimimos la velocidad final del coche usando el método obtenerVelocidad()
        System.out.println("Velocidad final: " + miCoche.obtenerVelocidad() + " km/h");
    }
}