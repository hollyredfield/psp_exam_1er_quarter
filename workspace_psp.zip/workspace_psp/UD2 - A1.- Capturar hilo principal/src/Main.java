// Main.java
public class Main {
    public static void main(String[] args) {
        // Imprime un mensaje indicando que el programa va a dormir
        System.out.println("El programa va a dormir");
        try {
            // Hace que el programa espere (duerma) 1000 milisegundos (1 segundo)
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // Si hay un error durante la espera, lo muestra
            System.out.println("Error");
        }
        // Imprime un mensaje indicando que el programa ha despertado
        System.out.println("El programa ha despertado");
    }
}