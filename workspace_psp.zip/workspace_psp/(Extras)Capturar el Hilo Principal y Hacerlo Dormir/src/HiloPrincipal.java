public class HiloPrincipal {
    public static void main(String[] args) {
        try {
            System.out.println("El hilo principal está en ejecución.");
            Thread.sleep(1000); // Pausa el hilo principal durante 1 segundo
            System.out.println("El hilo principal ha despertado.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}