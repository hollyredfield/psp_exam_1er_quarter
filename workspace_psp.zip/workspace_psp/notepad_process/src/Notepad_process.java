import java.io.IOException;
public class Notepad_process {
    public static void main (String[] agrs) {
        if (agrs.length == 0) {
            System.out.println("Por favor, proporciona el nombre del argumento de forma como texto");
            return;

        }

        String fileName = agrs[0];
        ProcessBuilder processBuilder = new ProcessBuilder("notepad.exe", "xd.txt" );

       try{
           processBuilder.start();
       } catch (IOException e) {
           e.printStackTrace();
       }


    }
}




