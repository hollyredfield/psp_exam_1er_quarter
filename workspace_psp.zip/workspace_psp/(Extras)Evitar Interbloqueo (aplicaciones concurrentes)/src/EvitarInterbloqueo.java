class Recurso {
    public synchronized void usar() {
        System.out.println(Thread.currentThread().getName() + " está usando el recurso.");
    }
}

public class EvitarInterbloqueo {
    public static void main(String[] args) {
        Recurso recurso1 = new Recurso();
        Recurso recurso2 = new Recurso();

        Runnable tarea1 = () -> {
            synchronized (recurso1) {
                System.out.println(Thread.currentThread().getName() + " ha bloqueado recurso1.");
                try { Thread.sleep(50); } catch (InterruptedException e) { e.printStackTrace(); }
                synchronized (recurso2) {
                    recurso2.usar();
                }
            }
        };

        Runnable tarea2 = () -> {
            synchronized (recurso1) { // Cambiar aquí el orden evita el interbloqueo
                System.out.println(Thread.currentThread().getName() + " ha bloqueado recurso1.");
                try { Thread.sleep(50); } catch (InterruptedException e) { e.printStackTrace(); }
                synchronized (recurso2) {
                    recurso2.usar();
                }
            }
        };

        Thread hilo1 = new Thread(tarea1, "Hilo 1");
        Thread hilo2 = new Thread(tarea2, "Hilo 2");

        hilo1.start();
        hilo2.start();
    }
}

