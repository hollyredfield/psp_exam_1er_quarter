class Contador implements Runnable {
    private String nombre;

    public Contador(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(nombre + " cuenta: " + i);
            try {
                Thread.sleep(500); // Pausa entre cada número
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
