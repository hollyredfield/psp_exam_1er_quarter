
public class Corredor implements Runnable {

	private String nombre;
	
	public Corredor(String nombre) {
		this.nombre = nombre;
	}
	
	@Override
	
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println(nombre + " ha avanzado " + i + " metros. ");
			try {
				Thread.sleep((int) (Math.random() * 100));
				
			} catch (InterruptedException e) {
				System.out.println(nombre + " ha terminado la carrera");
			}
		}
		System.out.println(nombre + " ha terminado la carrera.");
		}
			
	public static void main(String[]args) {
		Corredor corredor1 = new Corredor("Corredor1");
		Corredor corredor2 = new Corredor("Corredor2");
		Corredor corredor3 = new Corredor("Corredor3");
		
		Thread hilo1 = new Thread(corredor1);
		Thread hilo2 = new Thread(corredor2);
		Thread hilo3 = new Thread(corredor3);
		
		hilo1.start();
		hilo2.start();
		hilo3.start();
		
		try {
			hilo1.join();
			hilo2.join();
			hilo3.join();
		} catch (InterruptedException e ) {
		System.out.println("La carrera ha terminado");
	}
}
}