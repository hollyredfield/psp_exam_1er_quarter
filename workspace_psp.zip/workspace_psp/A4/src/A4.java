import java.io.*;

public class A4 {
    public static void main(String[] args) {
        File inputFile = new File("input.txt");
        if (!inputFile.exists()) {
            System.err.println("El archivo input.txt no se encuentra.");
            return;
        }

        try {
            ProcessBuilder pb = new ProcessBuilder("java", "MultiplicationTable");
            pb.redirectInput(inputFile);
            pb.redirectOutput(new File("output.txt"));
            pb.redirectError(new File("error.txt"));
            pb.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}