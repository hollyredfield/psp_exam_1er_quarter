class HiloConSleep extends Thread {
    @Override
    public void run() {
        try {
            System.out.println("El hilo está en ejecución.");
            Thread.sleep(2000); // Bloquea el hilo por 2 segundos
            System.out.println("El hilo ha salido de sleep.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
