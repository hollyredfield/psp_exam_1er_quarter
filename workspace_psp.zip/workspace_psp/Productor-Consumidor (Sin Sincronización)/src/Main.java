import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Integer> listaCompartida = new ArrayList<>();
        Thread productor = new Thread(new Productor(listaCompartida));
        Thread consumidor = new Thread(new Consumidor(listaCompartida));

        productor.start();
        consumidor.start();
    }
}
