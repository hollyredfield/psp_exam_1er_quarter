import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//Modo sincronizado

class Circunferencia {
    private double radio;
    
    public Circunferencia(double radio) {
        this.radio = radio;
    }
    
    public double calcularArea() {
        return Math.PI * radio;
    }
    
    
}

class Productora implements Runnable {
    private List<Double> radios;
    
    public Productora(List<Double> radios) {
        this.radios = radios;
    }
    
    @Override
    public void run() {
        Random random = new Random();
        for(int i = 0; i <10; i++) {
            double radio = random.nextDouble() * 10;
            System.out.println("Generador radio: " + radio );
            synchronized (radios) {
                radios.add(radio);
                radios.notify();
            }
            try {
                Thread.sleep(100);
            } catch(InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Consumidora implements Runnable {
    private List<Double> radios;
    
    public Consumidora(List<Double> radios) {
        this.radios = radios ;
    }
    
    @Override
    public void run() {
        for(int i = 0; i <10; i++) {
            synchronized (radios) {
                while(radios.isEmpty()){
                    try {
                        radios.wait();
                    } catch(InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                double radio = radios.remove(0);
                Circunferencia circunferencia = new Circunferencia(radio);
                System.out.println("Área de la circunferencia: " + circunferencia.calcularArea());
                
                
            }
            try {
                Thread.sleep(150);
            } catch (InterruptedException e ) {
                e.printStackTrace();
            }
        }
    }
}


public class Main{
    public static void main(String[]args) {
        List<Double> radios = new ArrayList<Double>();
        Thread productora = new Thread(new Productora(radios));
        Thread consumidora = new Thread(new Consumidora(radios));
        
        productora.start();
        consumidora.start();
    }
}