// Ave.java
public class Ave implements Animal { // Declara una clase llamada Ave que implementa la interfaz Animal
    @Override
    public void comer() { // Implementa el método comer de la interfaz Animal
        // Imprime un mensaje indicando que el ave come semillas
        System.out.println("El ave come semillas");
    }

    @Override
    public void dormir() { // Implementa el método dormir de la interfaz Animal
        // Imprime un mensaje indicando que el ave duerme
        System.out.println("El ave duerme");
    }

    public void volar() { // Método adicional que no está en la interfaz Animal
        // Imprime un mensaje indicando que el ave vuela
        System.out.println("El ave vuela");
    }
}
