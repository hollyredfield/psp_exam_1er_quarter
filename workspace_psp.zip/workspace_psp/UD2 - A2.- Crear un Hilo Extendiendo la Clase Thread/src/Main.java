// Main.java
public class Main {
    public static void main(String[] args) {
        // Crea un objeto Corredor con el nombre "Juan"
        Corredor corredor1 = new Corredor("Juan");
        // Crea un objeto Corredor con el nombre "Pedro"
        Corredor corredor2 = new Corredor("Pedro");
        // Crea un objeto Corredor con el nombre "Luis"
        Corredor corredor3 = new Corredor("Luis");

        // Inicia el hilo del corredor "Juan"
        corredor1.start();
        // Inicia el hilo del corredor "Pedro"
        corredor2.start();
        // Inicia el hilo del corredor "Luis"
        corredor3.start();
    }
}