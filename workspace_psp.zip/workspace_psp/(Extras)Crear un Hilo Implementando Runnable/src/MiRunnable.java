class MiRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("El hilo está ejecutándose con Runnable.");
    }
}
