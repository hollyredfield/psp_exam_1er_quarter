import java.util.Random;

class Corredor implements Runnable {
    private String nombre;

    public Corredor(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void run() {
        Random random = new Random();
        int progreso = 0;
        while (progreso < 100) {
            progreso += random.nextInt(10) + 1; // Avance aleatorio entre 1 y 10
            System.out.println(nombre + " ha avanzado a " + progreso + "%.");
            try {
                Thread.sleep(200); // Simula tiempo de avance
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(nombre + " ha terminado la carrera.");
    }
}
