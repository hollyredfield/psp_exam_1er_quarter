/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author holly
 */
// 2. Productor.java - Genera números aleatorios (radios) y los guarda
import java.util.ArrayList;

public class Productor implements Runnable {
    // Lista donde guardamos los radios
    private ArrayList<Double> radios;
    
    public Productor(ArrayList<Double> radios) {
        this.radios = radios;
    }
    
    @Override
    public void run() {
        // Genera 5 radios aleatorios
        for(int i = 0; i < 5; i++) {
            double radio = Math.random() * 10; // Número entre 0 y 10
            radios.add(radio); // Añade el radio a la lista
            System.out.println("Productor creó radio: " + radio);
            try {
                Thread.sleep(1000); // Espera 1 segundo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}