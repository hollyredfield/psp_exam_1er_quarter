// Main.java
public class Main {
    public static void main(String[] args) {
        try {
            // Imprime un mensaje indicando que las carreras están por iniciar
            System.out.println("Iniciando carreras...");
            
            // Primera carrera
            // Crea un hilo para el caballo "Relámpago" en la carrera "carrera1"
            Thread caballo1 = new Thread(new Caballo("Relámpago", "carrera1"));
            // Crea un hilo para el caballo "Tormenta" en la carrera "carrera1"
            Thread caballo2 = new Thread(new Caballo("Tormenta", "carrera1"));
            // Crea un hilo para el caballo "Veloz" en la carrera "carrera1"
            Thread caballo3 = new Thread(new Caballo("Veloz", "carrera1"));
            
            // Segunda carrera
            // Crea un hilo para el caballo "Rayo" en la carrera "carrera2"
            Thread caballo4 = new Thread(new Caballo("Rayo", "carrera2"));
            // Crea un hilo para el caballo "Trueno" en la carrera "carrera2"
            Thread caballo5 = new Thread(new Caballo("Trueno", "carrera2"));
            // Crea un hilo para el caballo "Furioso" en la carrera "carrera2"
            Thread caballo6 = new Thread(new Caballo("Furioso", "carrera2"));
            
            // Inicia las carreras
            caballo1.start(); // Inicia el hilo del caballo "Relámpago"
            caballo2.start(); // Inicia el hilo del caballo "Tormenta"
            caballo3.start(); // Inicia el hilo del caballo "Veloz"
            caballo4.start(); // Inicia el hilo del caballo "Rayo"
            caballo5.start(); // Inicia el hilo del caballo "Trueno"
            caballo6.start(); // Inicia el hilo del caballo "Furioso"
            
            // Imprime un mensaje indicando que las carreras han iniciado y dónde revisar los resultados
            System.out.println("Carreras iniciadas. Revisa los archivos carrera1.txt y carrera2.txt");
            
        } catch (Exception e) {
            // Si hay un error en el programa principal, lo muestra
            System.out.println("Error en el programa principal");
        }
    }
}