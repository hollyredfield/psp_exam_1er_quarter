import java.util.LinkedList;
import java.util.Queue;

class ProductorSync implements Runnable {
    private final Queue<Integer> cola;
    private final int capacidad;

    public ProductorSync(Queue<Integer> cola, int capacidad) {
        this.cola = cola;
        this.capacidad = capacidad;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            synchronized (cola) {
                while (cola.size() == capacidad) {
                    try {
                        cola.wait(); // Espera si la cola está llena
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                cola.add(i);
                System.out.println("Produciendo: " + i);
                cola.notify(); // Notifica al consumidor
            }
        }
    }
}

class ConsumidorSync implements Runnable {
    private final Queue<Integer> cola;

    public ConsumidorSync(Queue<Integer> cola) {
        this.cola = cola;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            synchronized (cola) {
                while (cola.isEmpty()) {
                    try {
                        cola.wait(); // Espera si la cola está vacía
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                int valor = cola.poll();
                System.out.println("Consumiendo: " + valor);
                cola.notify(); // Notifica al productor
            }
        }
    }
}
