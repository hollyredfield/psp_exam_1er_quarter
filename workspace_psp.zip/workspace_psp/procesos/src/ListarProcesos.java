import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ListarProcesos {
    public static void main(String[] args) {
        try {
            // Comando para el sistema operativo
            String os = System.getProperty("os.name").toLowerCase();
            String command;
            if (os.contains("win")) {
                command = "tasklist";
            } else {
                command = "ps -e";
            }

            // Ejecut0 el comando
            ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
            Process process = processBuilder.start();

            // Leo la salida del comando
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            // Espero a que el proceso termine
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}