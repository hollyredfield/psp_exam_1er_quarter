// Definimos una interfaz llamada Dispositivo
// Una interfaz es como un contrato que dice qué métodos deben tener las clases que la implementen
public interface Dispositivo {
    // Método para encender el dispositivo
    void encender();
    
    // Método para apagar el dispositivo
    void apagar();
    
    // Método para mostrar el estado del dispositivo (encendido o apagado)
    void mostrarEstado();
}