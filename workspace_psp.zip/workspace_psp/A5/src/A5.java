public class A5 {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java MultiplicationTable <number>");
            return;
        }

        int number = Integer.parseInt(args[0]);
        for (int i = 1; i <= 10; i++) {
            System.out.println(number + " x " + i + " = " + (number * i));
        }
    }
}