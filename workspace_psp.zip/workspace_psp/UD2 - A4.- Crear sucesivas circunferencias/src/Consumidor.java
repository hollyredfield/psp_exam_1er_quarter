/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author holly
 */
// 3. Consumidor.java - Toma los radios y crea circunferencias
import java.util.ArrayList;

public class Consumidor implements Runnable {
    // Usa la misma lista que el productor
    private ArrayList<Double> radios;
    
    public Consumidor(ArrayList<Double> radios) {
        this.radios = radios;
    }
    
    @Override
    public void run() {
        // Intenta crear 5 circunferencias
        for(int i = 0; i < 5; i++) {
            if(!radios.isEmpty()) { // Si hay radios disponibles
                double radio = radios.remove(0); // Toma el primer radio
                Circunferencia c = new Circunferencia(radio);
                System.out.println("Consumidor creó: " + c);
            }
            try {
                Thread.sleep(1500); // Espera 1.5 segundos
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}