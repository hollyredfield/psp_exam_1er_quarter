// Corredor.java
public class Corredor extends Thread { // Declara la clase Corredor que extiende la clase Thread
    String nombre; // Declara una variable para almacenar el nombre del corredor

    public Corredor(String nombre) { // Constructor de la clase Corredor
        this.nombre = nombre; // Asigna el nombre del corredor
    }

    public void run() { // Método que se ejecuta cuando se inicia el hilo
        // Imprime un mensaje indicando que el corredor empieza a correr
        System.out.println(nombre + " empieza a correr");
        try {
            // Espera 1000 milisegundos (1 segundo)
            Thread.sleep(1000);
            // Imprime un mensaje indicando que el corredor va por la mitad
            System.out.println(nombre + " va por la mitad");
            // Espera otros 1000 milisegundos (1 segundo)
            Thread.sleep(1000);
            // Imprime un mensaje indicando que el corredor ha terminado
            System.out.println(nombre + " ha terminado!");
        } catch (InterruptedException e) {
            // Si hay un error durante la espera, lo muestra
            System.out.println("Error");
        }
    }
}