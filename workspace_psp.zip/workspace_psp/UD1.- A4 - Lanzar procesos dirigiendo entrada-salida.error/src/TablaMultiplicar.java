// TablaMultiplicar.java
import java.util.Scanner; // Importa la clase Scanner para leer la entrada del usuario

public class TablaMultiplicar {
    public static void main(String[] args) {
        try {
            // Crea un objeto Scanner para leer la entrada del usuario
            Scanner scanner = new Scanner(System.in);
            // Lee un número entero desde la entrada del usuario
            int numero = scanner.nextInt();
            
            // Bucle que va del 1 al 10
            for (int i = 1; i <= 10; i++) {
                // Imprime la tabla de multiplicar del número leído
                System.out.println(numero + " x " + i + " = " + (numero * i));
            }
            
            // Cierra el objeto Scanner
            scanner.close();
        } catch (Exception e) {
            // Si hay un error, lo muestra
            System.err.println("Error: " + e);
        }
    }
}