public class Main {
    public static void main(String[] args) {
        Thread corredor1 = new Thread(new Corredor("Corredor 1"));
        Thread corredor2 = new Thread(new Corredor("Corredor 2"));
        Thread corredor3 = new Thread(new Corredor("Corredor 3"));

        corredor1.start();
        corredor2.start();
        corredor3.start();
    }
}
