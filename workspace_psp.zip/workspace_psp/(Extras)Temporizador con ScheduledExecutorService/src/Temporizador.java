import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Temporizador {
    public static void main(String[] args) {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        Runnable tarea = () -> System.out.println("Tarea periódica ejecutada.");

        scheduler.scheduleAtFixedRate(tarea, 0, 2, TimeUnit.SECONDS);

        try {
            Thread.sleep(10000); // Deja correr el temporizador durante 10 segundos
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        scheduler.shutdown();
    }
}
