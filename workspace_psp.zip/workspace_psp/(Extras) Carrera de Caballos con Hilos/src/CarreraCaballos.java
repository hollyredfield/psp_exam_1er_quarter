import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

class Caballo implements Runnable {
    private final String nombre;
    private final CountDownLatch latch;

    public Caballo(String nombre, CountDownLatch latch) {
        this.nombre = nombre;
        this.latch = latch;
    }

    @Override
    public void run() {
        Random random = new Random();
        int progreso = 0;

        while (progreso < 100) {
            progreso += random.nextInt(10) + 1;
            System.out.println(nombre + " avanza a " + progreso + "%.");
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(nombre + " ha terminado la carrera.");
        latch.countDown(); // Decrementa el contador del latch
    }
}

public class CarreraCaballos {
    public static void main(String[] args) throws IOException, InterruptedException {
        String[] nombres = {"Caballo 1", "Caballo 2", "Caballo 3"};
        CountDownLatch latch = new CountDownLatch(nombres.length);

        try (FileWriter escritor = new FileWriter("resultados.txt")) {
            for (String nombre : nombres) {
                new Thread(new Caballo(nombre, latch)).start();
            }

            latch.await(); // Espera a que todos los caballos terminen
            escritor.write("La carrera ha terminado. Todos los caballos han llegado.");
        }
    }
}
