public class Mamifero extends AnimalBase{
    public Mamifero (String nombre) {
        super(nombre);
    }
    public void caminar() {
        System.out.println(getNombre() + " está caminando. ");

    }
}
