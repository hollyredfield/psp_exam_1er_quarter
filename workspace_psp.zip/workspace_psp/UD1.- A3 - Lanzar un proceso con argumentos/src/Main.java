// Main.java

import java.io.FileWriter; // Importa la clase FileWriter para escribir en archivos

public class Main {
    public static void main(String[] args) {
        try {
            // Crear un archivo de texto para probar
            FileWriter fw = new FileWriter("prueba.txt"); // Crea un FileWriter para el archivo "prueba.txt"
            fw.write("Hola Mundo"); // Escribe "Hola Mundo" en el archivo
            fw.close(); // Cierra el FileWriter

            // Abrir Notepad con el archivo
            ProcessBuilder pb = new ProcessBuilder(
                "notepad.exe", // Especifica que se debe ejecutar Notepad
                "prueba.txt" // Especifica que se debe abrir el archivo "prueba.txt"
            );
            
            pb.start(); // Inicia el proceso para abrir Notepad
            
            // Imprime un mensaje indicando que Notepad se ha abierto
            System.out.println("Notepad abierto");
            
        } catch (Exception e) {
            // Si hay un error, lo muestra
            System.out.println("Error: " + e);
        }
    }
}