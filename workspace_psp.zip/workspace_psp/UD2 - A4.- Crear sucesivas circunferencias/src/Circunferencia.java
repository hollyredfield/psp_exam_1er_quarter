/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author holly
 */
// 1. Circunferencia.java - La clase más simple, solo guarda un radio
public class Circunferencia {
    private double radio;
    
    public Circunferencia(double radio) {
        this.radio = radio;
    }
    
    @Override
    public String toString() {
        return "Circunferencia de radio: " + radio;
    }
}