import java.util.ArrayList;
import java.util.List;

class Productor implements Runnable {
    private final List<Integer> lista;

    public Productor(List<Integer> lista) {
        this.lista = lista;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println("Produciendo: " + i);
            lista.add(i);
            try {
                Thread.sleep(500); // Simula tiempo de producción
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Consumidor implements Runnable {
    private final List<Integer> lista;

    public Consumidor(List<Integer> lista) {
        this.lista = lista;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            if (!lista.isEmpty()) {
                System.out.println("Consumiendo: " + lista.remove(0));
            }
            try {
                Thread.sleep(700); // Simula tiempo de consumo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
