// Definimos la clase principal Main
public class Main {
    // Método principal que se ejecuta al iniciar el programa
    public static void main(String[] args) {
        // Creamos una instancia de la clase Telefono
        Telefono miTelefono = new Telefono();
        
        // Llamamos al método mostrarEstado() para ver si el teléfono está encendido o apagado
        miTelefono.mostrarEstado();
        
        // Llamamos al método encender() para encender el teléfono
        miTelefono.encender();
        
        // Llamamos al método realizarLlamada() para simular una llamada
        miTelefono.realizarLlamada();
        
        // Llamamos al método apagar() para apagar el teléfono
        miTelefono.apagar();
        
        // Llamamos nuevamente al método mostrarEstado() para ver si el teléfono está encendido o apagado
        miTelefono.mostrarEstado();
    }
}