// La clase Coche implementa la interfaz Vehiculo
public class Coche implements Vehiculo {
    // Atributo privado para almacenar la velocidad del coche
    private int velocidad = 0;
    // Atributo privado para indicar si el coche tiene aire acondicionado
    private boolean tieneAireAcondicionado = true;
    
    // Implementación del método acelerar() de la interfaz Vehiculo
    @Override
    public void acelerar() {
        // Incrementamos la velocidad en 10 km/h
        velocidad += 10;
        // Imprimimos la nueva velocidad del coche
        System.out.println("Coche acelera a " + velocidad + " km/h");
    }
    
    // Implementación del método frenar() de la interfaz Vehiculo
    @Override
    public void frenar() {
        // Reducimos la velocidad en 5 km/h
        velocidad -= 5;
        // Aseguramos que la velocidad no sea negativa
        if (velocidad < 0) velocidad = 0;
        // Imprimimos la nueva velocidad del coche
        System.out.println("Coche frena a " + velocidad + " km/h");
    }
    
    // Implementación del método obtenerVelocidad() de la interfaz Vehiculo
    @Override
    public int obtenerVelocidad() {
        // Devolvemos la velocidad actual del coche
        return velocidad;
    }
    
    // Método específico de la clase Coche para usar el aire acondicionado
    public void usarAireAcondicionado() {
        // Cambiamos el estado del aire acondicionado (encendido/apagado)
        tieneAireAcondicionado = !tieneAireAcondicionado;
        // Imprimimos el estado actual del aire acondicionado
        System.out.println("Aire acondicionado " + (tieneAireAcondicionado ? "encendido" : "apagado"));
    }
}