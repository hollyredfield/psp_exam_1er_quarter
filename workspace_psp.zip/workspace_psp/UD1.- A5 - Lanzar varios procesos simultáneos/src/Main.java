import java.io.File; // Importa la clase File para manejar archivos

public class Main {
    public static void main(String[] args) {
        try {
            // Obtiene el classpath del sistema
            String classpath = System.getProperty("java.class.path");
            // Crea un ProcessBuilder para ejecutar la clase TablaMultiplicar con el argumento "2"
            ProcessBuilder pb1 = new ProcessBuilder("java", "-cp", classpath, "TablaMultiplicar", "2");
            // Crea un ProcessBuilder para ejecutar la clase TablaMultiplicar con el argumento "3"
            ProcessBuilder pb2 = new ProcessBuilder("java", "-cp", classpath, "TablaMultiplicar", "3");
            // Crea un ProcessBuilder para ejecutar la clase TablaMultiplicar con el argumento "4"
            ProcessBuilder pb3 = new ProcessBuilder("java", "-cp", classpath, "TablaMultiplicar", "4");

            // Redirige la salida del proceso pb1 al archivo "tabla2.txt"
            pb1.redirectOutput(new File("tabla2.txt"));
            // Redirige la salida del proceso pb2 al archivo "tabla3.txt"
            pb2.redirectOutput(new File("tabla3.txt"));
            // Redirige la salida del proceso pb3 al archivo "tabla4.txt"
            pb3.redirectOutput(new File("tabla4.txt"));

            // Inicia el proceso pb1
            Process p1 = pb1.start();
            // Inicia el proceso pb2
            Process p2 = pb2.start();
            // Inicia el proceso pb3
            Process p3 = pb3.start();

            // Espera a que el proceso p1 termine
            p1.waitFor();
            // Espera a que el proceso p2 termine
            p2.waitFor();
            // Espera a que el proceso p3 termine
            p3.waitFor();

            // Imprime un mensaje indicando que las tablas se han generado
            System.out.println("Tablas generadas en tabla2.txt, tabla3.txt y tabla4.txt");
        } catch (Exception e) {
            // Si hay un error, lo muestra
            System.out.println("Error: " + e.getMessage());
        }
    }
}