import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        Queue<Integer> cola = new LinkedList<>();
        int capacidad = 5;

        Thread productor = new Thread(new ProductorSync(cola, capacidad));
        Thread consumidor = new Thread(new ConsumidorSync(cola));

        productor.start();
        consumidor.start();
    }
}
