class CuentaBancaria {
    private int saldo = 100;

    public synchronized void retirarDinero(int cantidad, String cliente) {
        if (saldo >= cantidad) {
            System.out.println(cliente + " está retirando " + cantidad + " euros.");
            saldo -= cantidad;
            System.out.println(cliente + " ha retirado el dinero. Saldo restante: " + saldo);
        } else {
            System.out.println(cliente + " no puede retirar dinero. Saldo insuficiente.");
        }
    }
}
