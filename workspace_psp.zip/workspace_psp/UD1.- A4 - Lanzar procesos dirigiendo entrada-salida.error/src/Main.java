// Main.java
import java.io.File;

public class Main {
    public static void main(String[] args) {
        try {
            // Obtener classpath actual
            String classpath = System.getProperty("java.class.path");
            
            // Crear ProcessBuilder con classpath
            ProcessBuilder pb = new ProcessBuilder(
                "java",
                "-cp",
                classpath,
                "TablaMultiplicar"
            );
            
            // Crear y escribir archivo de entrada
            File inputFile = new File("entrada.txt");
            java.io.FileWriter writer = new java.io.FileWriter(inputFile);
            writer.write("5");
            writer.close();
            
            // Configurar redirecciones
            pb.redirectInput(inputFile);
            pb.redirectOutput(new File("salida.txt"));
            pb.redirectError(new File("errores.txt"));
            
            // Ejecutar proceso
            Process p = pb.start();
            p.waitFor();
            
            System.out.println("Proceso completado. Revisa los archivos generados.");
            
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}